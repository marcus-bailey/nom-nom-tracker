--
-- PostgreSQL database dump
--

\restrict yJ2tXhTQhwG06TjnpGfaUvL7RSdWViUfNljKh0NrryooSvM2ifiExhq0wodbpaR

-- Dumped from database version 15.15
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: food_log; Type: TABLE; Schema: public; Owner: nomnom
--

CREATE TABLE public.food_log (
    id integer NOT NULL,
    log_date date NOT NULL,
    log_time time without time zone NOT NULL,
    food_id integer,
    meal_id integer,
    servings numeric(10,2) DEFAULT 1 NOT NULL,
    calories numeric(10,2) NOT NULL,
    protein_grams numeric(10,2) NOT NULL,
    carbs_grams numeric(10,2) NOT NULL,
    net_carbs_grams numeric(10,2) NOT NULL,
    fiber_grams numeric(10,2) NOT NULL,
    fat_grams numeric(10,2) NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT food_log_check CHECK (((food_id IS NOT NULL) OR (meal_id IS NOT NULL)))
);


ALTER TABLE public.food_log OWNER TO nomnom;

--
-- Name: food_log_id_seq; Type: SEQUENCE; Schema: public; Owner: nomnom
--

CREATE SEQUENCE public.food_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.food_log_id_seq OWNER TO nomnom;

--
-- Name: food_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nomnom
--

ALTER SEQUENCE public.food_log_id_seq OWNED BY public.food_log.id;


--
-- Name: foods; Type: TABLE; Schema: public; Owner: nomnom
--

CREATE TABLE public.foods (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    calories numeric(10,2) NOT NULL,
    protein_grams numeric(10,2) DEFAULT 0 NOT NULL,
    carbs_grams numeric(10,2) DEFAULT 0 NOT NULL,
    fiber_grams numeric(10,2) DEFAULT 0 NOT NULL,
    fat_grams numeric(10,2) DEFAULT 0 NOT NULL,
    serving_size character varying(100),
    serving_unit character varying(50),
    is_custom boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.foods OWNER TO nomnom;

--
-- Name: foods_id_seq; Type: SEQUENCE; Schema: public; Owner: nomnom
--

CREATE SEQUENCE public.foods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.foods_id_seq OWNER TO nomnom;

--
-- Name: foods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nomnom
--

ALTER SEQUENCE public.foods_id_seq OWNED BY public.foods.id;


--
-- Name: meal_foods; Type: TABLE; Schema: public; Owner: nomnom
--

CREATE TABLE public.meal_foods (
    id integer NOT NULL,
    meal_id integer NOT NULL,
    food_id integer NOT NULL,
    servings numeric(10,2) DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.meal_foods OWNER TO nomnom;

--
-- Name: meal_foods_id_seq; Type: SEQUENCE; Schema: public; Owner: nomnom
--

CREATE SEQUENCE public.meal_foods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meal_foods_id_seq OWNER TO nomnom;

--
-- Name: meal_foods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nomnom
--

ALTER SEQUENCE public.meal_foods_id_seq OWNED BY public.meal_foods.id;


--
-- Name: meals; Type: TABLE; Schema: public; Owner: nomnom
--

CREATE TABLE public.meals (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_custom boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.meals OWNER TO nomnom;

--
-- Name: meals_id_seq; Type: SEQUENCE; Schema: public; Owner: nomnom
--

CREATE SEQUENCE public.meals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meals_id_seq OWNER TO nomnom;

--
-- Name: meals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nomnom
--

ALTER SEQUENCE public.meals_id_seq OWNED BY public.meals.id;


--
-- Name: food_log id; Type: DEFAULT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.food_log ALTER COLUMN id SET DEFAULT nextval('public.food_log_id_seq'::regclass);


--
-- Name: foods id; Type: DEFAULT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.foods ALTER COLUMN id SET DEFAULT nextval('public.foods_id_seq'::regclass);


--
-- Name: meal_foods id; Type: DEFAULT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods ALTER COLUMN id SET DEFAULT nextval('public.meal_foods_id_seq'::regclass);


--
-- Name: meals id; Type: DEFAULT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meals ALTER COLUMN id SET DEFAULT nextval('public.meals_id_seq'::regclass);


--
-- Data for Name: food_log; Type: TABLE DATA; Schema: public; Owner: nomnom
--

COPY public.food_log (id, log_date, log_time, food_id, meal_id, servings, calories, protein_grams, carbs_grams, net_carbs_grams, fiber_grams, fat_grams, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: foods; Type: TABLE DATA; Schema: public; Owner: nomnom
--

COPY public.foods (id, name, calories, protein_grams, carbs_grams, fiber_grams, fat_grams, serving_size, serving_unit, is_custom, created_at, updated_at) FROM stdin;
1	Chicken Breast (cooked)	165.00	31.00	0.00	0.00	3.60	100	g	f	2025-11-16 19:57:53.804158	2025-11-16 19:57:53.804158
2	Salmon (cooked)	206.00	22.00	0.00	0.00	13.00	100	g	f	2025-11-16 19:57:53.806362	2025-11-16 19:57:53.806362
3	Ground Beef 85/15 (cooked)	215.00	26.00	0.00	0.00	12.00	100	g	f	2025-11-16 19:57:53.806741	2025-11-16 19:57:53.806741
4	Eggs (large)	72.00	6.00	0.40	0.00	5.00	1	egg	f	2025-11-16 19:57:53.807038	2025-11-16 19:57:53.807038
5	Greek Yogurt (plain, nonfat)	59.00	10.00	3.60	0.00	0.40	100	g	f	2025-11-16 19:57:53.807265	2025-11-16 19:57:53.807265
6	Tofu (firm)	144.00	17.00	3.00	2.00	9.00	100	g	f	2025-11-16 19:57:53.807469	2025-11-16 19:57:53.807469
7	Brown Rice (cooked)	112.00	2.60	24.00	1.80	0.90	100	g	f	2025-11-16 19:57:53.807736	2025-11-16 19:57:53.807736
8	White Rice (cooked)	130.00	2.70	28.00	0.40	0.30	100	g	f	2025-11-16 19:57:53.807934	2025-11-16 19:57:53.807934
9	Sweet Potato (baked)	90.00	2.00	21.00	3.30	0.20	100	g	f	2025-11-16 19:57:53.808219	2025-11-16 19:57:53.808219
10	Oatmeal (cooked)	71.00	2.50	12.00	1.70	1.50	100	g	f	2025-11-16 19:57:53.808601	2025-11-16 19:57:53.808601
11	Quinoa (cooked)	120.00	4.40	21.00	2.80	1.90	100	g	f	2025-11-16 19:57:53.808932	2025-11-16 19:57:53.808932
12	Whole Wheat Bread	247.00	13.00	41.00	7.00	3.40	100	g	f	2025-11-16 19:57:53.809127	2025-11-16 19:57:53.809127
13	Banana	89.00	1.10	23.00	2.60	0.30	1	medium	f	2025-11-16 19:57:53.809356	2025-11-16 19:57:53.809356
14	Apple	52.00	0.30	14.00	2.40	0.20	1	medium	f	2025-11-16 19:57:53.809624	2025-11-16 19:57:53.809624
15	Broccoli (cooked)	35.00	2.40	7.00	3.30	0.40	100	g	f	2025-11-16 19:57:53.809835	2025-11-16 19:57:53.809835
16	Spinach (raw)	23.00	2.90	3.60	2.20	0.40	100	g	f	2025-11-16 19:57:53.810178	2025-11-16 19:57:53.810178
17	Carrots (raw)	41.00	0.90	10.00	2.80	0.20	100	g	f	2025-11-16 19:57:53.81053	2025-11-16 19:57:53.81053
18	Bell Pepper (raw)	31.00	1.00	6.00	2.10	0.30	100	g	f	2025-11-16 19:57:53.810769	2025-11-16 19:57:53.810769
19	Kale (raw)	35.00	2.90	4.40	4.10	1.50	100	g	f	2025-11-16 19:57:53.81095	2025-11-16 19:57:53.81095
20	Avocado	160.00	2.00	8.50	6.70	15.00	100	g	f	2025-11-16 19:57:53.811119	2025-11-16 19:57:53.811119
21	Almonds	579.00	21.00	22.00	12.50	50.00	100	g	f	2025-11-16 19:57:53.811333	2025-11-16 19:57:53.811333
22	Olive Oil	884.00	0.00	0.00	0.00	100.00	100	ml	f	2025-11-16 19:57:53.811547	2025-11-16 19:57:53.811547
23	Peanut Butter	588.00	25.00	20.00	6.00	50.00	100	g	f	2025-11-16 19:57:53.811718	2025-11-16 19:57:53.811718
24	Cheddar Cheese	403.00	25.00	1.30	0.00	33.00	100	g	f	2025-11-16 19:57:53.811964	2025-11-16 19:57:53.811964
25	Whole Milk	61.00	3.20	4.80	0.00	3.30	100	ml	f	2025-11-16 19:57:53.812134	2025-11-16 19:57:53.812134
26	Skim Milk	34.00	3.40	5.00	0.00	0.10	100	ml	f	2025-11-16 19:57:53.812298	2025-11-16 19:57:53.812298
27	Whey Protein Powder	400.00	80.00	8.00	2.00	8.00	100	g	f	2025-11-16 19:57:53.812457	2025-11-16 19:57:53.812457
\.


--
-- Data for Name: meal_foods; Type: TABLE DATA; Schema: public; Owner: nomnom
--

COPY public.meal_foods (id, meal_id, food_id, servings, created_at) FROM stdin;
\.


--
-- Data for Name: meals; Type: TABLE DATA; Schema: public; Owner: nomnom
--

COPY public.meals (id, name, description, is_custom, created_at, updated_at) FROM stdin;
\.


--
-- Name: food_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nomnom
--

SELECT pg_catalog.setval('public.food_log_id_seq', 1, false);


--
-- Name: foods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nomnom
--

SELECT pg_catalog.setval('public.foods_id_seq', 54, true);


--
-- Name: meal_foods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nomnom
--

SELECT pg_catalog.setval('public.meal_foods_id_seq', 1, false);


--
-- Name: meals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nomnom
--

SELECT pg_catalog.setval('public.meals_id_seq', 1, false);


--
-- Name: food_log food_log_pkey; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.food_log
    ADD CONSTRAINT food_log_pkey PRIMARY KEY (id);


--
-- Name: foods foods_name_key; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT foods_name_key UNIQUE (name);


--
-- Name: foods foods_pkey; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT foods_pkey PRIMARY KEY (id);


--
-- Name: meal_foods meal_foods_meal_id_food_id_key; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods
    ADD CONSTRAINT meal_foods_meal_id_food_id_key UNIQUE (meal_id, food_id);


--
-- Name: meal_foods meal_foods_pkey; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods
    ADD CONSTRAINT meal_foods_pkey PRIMARY KEY (id);


--
-- Name: meals meals_pkey; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meals
    ADD CONSTRAINT meals_pkey PRIMARY KEY (id);


--
-- Name: idx_food_log_date; Type: INDEX; Schema: public; Owner: nomnom
--

CREATE INDEX idx_food_log_date ON public.food_log USING btree (log_date);


--
-- Name: idx_foods_name; Type: INDEX; Schema: public; Owner: nomnom
--

CREATE INDEX idx_foods_name ON public.foods USING btree (name);


--
-- Name: idx_meals_name; Type: INDEX; Schema: public; Owner: nomnom
--

CREATE INDEX idx_meals_name ON public.meals USING btree (name);


--
-- Name: food_log food_log_food_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.food_log
    ADD CONSTRAINT food_log_food_id_fkey FOREIGN KEY (food_id) REFERENCES public.foods(id) ON DELETE SET NULL;


--
-- Name: food_log food_log_meal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.food_log
    ADD CONSTRAINT food_log_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id) ON DELETE SET NULL;


--
-- Name: meal_foods meal_foods_food_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods
    ADD CONSTRAINT meal_foods_food_id_fkey FOREIGN KEY (food_id) REFERENCES public.foods(id) ON DELETE CASCADE;


--
-- Name: meal_foods meal_foods_meal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods
    ADD CONSTRAINT meal_foods_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict yJ2tXhTQhwG06TjnpGfaUvL7RSdWViUfNljKh0NrryooSvM2ifiExhq0wodbpaR

