--
-- PostgreSQL database dump
--

\restrict gUSqEBZNEidv7gzKKbJXxzq8kwrAhSottxxgnWi6hxzqzGFHjyigK65FYltn00X

-- Dumped from database version 15.15
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: food_log; Type: TABLE; Schema: public; Owner: nomnom
--

CREATE TABLE public.food_log (
    id integer NOT NULL,
    log_date date NOT NULL,
    log_time time without time zone NOT NULL,
    food_id integer,
    meal_id integer,
    servings numeric(10,2) DEFAULT 1 NOT NULL,
    calories numeric(10,2) NOT NULL,
    protein_grams numeric(10,2) NOT NULL,
    carbs_grams numeric(10,2) NOT NULL,
    net_carbs_grams numeric(10,2) NOT NULL,
    fiber_grams numeric(10,2) NOT NULL,
    fat_grams numeric(10,2) NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT food_log_check CHECK (((food_id IS NOT NULL) OR (meal_id IS NOT NULL)))
);


ALTER TABLE public.food_log OWNER TO nomnom;

--
-- Name: food_log_id_seq; Type: SEQUENCE; Schema: public; Owner: nomnom
--

CREATE SEQUENCE public.food_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.food_log_id_seq OWNER TO nomnom;

--
-- Name: food_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nomnom
--

ALTER SEQUENCE public.food_log_id_seq OWNED BY public.food_log.id;


--
-- Name: foods; Type: TABLE; Schema: public; Owner: nomnom
--

CREATE TABLE public.foods (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    calories numeric(10,2) NOT NULL,
    protein_grams numeric(10,2) DEFAULT 0 NOT NULL,
    carbs_grams numeric(10,2) DEFAULT 0 NOT NULL,
    fiber_grams numeric(10,2) DEFAULT 0 NOT NULL,
    fat_grams numeric(10,2) DEFAULT 0 NOT NULL,
    serving_size character varying(100),
    serving_unit character varying(50),
    is_custom boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.foods OWNER TO nomnom;

--
-- Name: foods_id_seq; Type: SEQUENCE; Schema: public; Owner: nomnom
--

CREATE SEQUENCE public.foods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.foods_id_seq OWNER TO nomnom;

--
-- Name: foods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nomnom
--

ALTER SEQUENCE public.foods_id_seq OWNED BY public.foods.id;


--
-- Name: meal_foods; Type: TABLE; Schema: public; Owner: nomnom
--

CREATE TABLE public.meal_foods (
    id integer NOT NULL,
    meal_id integer NOT NULL,
    food_id integer NOT NULL,
    servings numeric(10,2) DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.meal_foods OWNER TO nomnom;

--
-- Name: meal_foods_id_seq; Type: SEQUENCE; Schema: public; Owner: nomnom
--

CREATE SEQUENCE public.meal_foods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meal_foods_id_seq OWNER TO nomnom;

--
-- Name: meal_foods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nomnom
--

ALTER SEQUENCE public.meal_foods_id_seq OWNED BY public.meal_foods.id;


--
-- Name: meals; Type: TABLE; Schema: public; Owner: nomnom
--

CREATE TABLE public.meals (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    is_custom boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.meals OWNER TO nomnom;

--
-- Name: meals_id_seq; Type: SEQUENCE; Schema: public; Owner: nomnom
--

CREATE SEQUENCE public.meals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.meals_id_seq OWNER TO nomnom;

--
-- Name: meals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nomnom
--

ALTER SEQUENCE public.meals_id_seq OWNED BY public.meals.id;


--
-- Name: food_log id; Type: DEFAULT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.food_log ALTER COLUMN id SET DEFAULT nextval('public.food_log_id_seq'::regclass);


--
-- Name: foods id; Type: DEFAULT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.foods ALTER COLUMN id SET DEFAULT nextval('public.foods_id_seq'::regclass);


--
-- Name: meal_foods id; Type: DEFAULT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods ALTER COLUMN id SET DEFAULT nextval('public.meal_foods_id_seq'::regclass);


--
-- Name: meals id; Type: DEFAULT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meals ALTER COLUMN id SET DEFAULT nextval('public.meals_id_seq'::regclass);


--
-- Data for Name: food_log; Type: TABLE DATA; Schema: public; Owner: nomnom
--

COPY public.food_log (id, log_date, log_time, food_id, meal_id, servings, calories, protein_grams, carbs_grams, net_carbs_grams, fiber_grams, fat_grams, notes, created_at, updated_at) FROM stdin;
3	2025-12-06	08:29:44	\N	1	1.00	179.00	13.10	32.00	26.40	5.60	3.30	\N	2025-12-06 15:29:44.995606	2025-12-06 15:29:44.995606
4	2025-12-07	10:37:09	\N	1	1.00	179.00	13.10	32.00	26.40	5.60	3.30	\N	2025-12-07 17:37:09.436077	2025-12-07 17:37:09.436077
5	2026-01-01	09:46:54	\N	2	1.00	290.00	21.00	0.00	0.00	0.00	23.00	\N	2026-01-01 16:46:54.197942	2026-01-01 16:46:54.197942
7	2026-01-02	13:21:24	61	\N	1.00	460.00	24.00	54.00	50.00	4.00	16.00	\N	2026-01-02 13:21:24.55851	2026-01-02 13:21:24.55851
8	2026-01-02	13:33:23	\N	3	1.00	372.00	18.00	2.95	2.95	0.00	31.50	\N	2026-01-02 13:33:23.886974	2026-01-02 13:33:23.886974
10	2026-01-02	13:35:21	62	\N	2.00	200.00	36.00	14.00	14.00	0.00	0.00	\N	2026-01-02 13:35:21.562881	2026-01-02 13:35:21.562881
11	2026-01-03	08:18:52	\N	3	1.00	372.00	18.00	2.95	2.95	0.00	31.50	\N	2026-01-03 08:18:53.097621	2026-01-03 08:18:53.097621
12	2026-01-03	08:41:10	\N	4	1.50	165.00	1.50	1.50	1.50	0.00	16.50	\N	2026-01-03 08:41:10.741508	2026-01-03 08:41:10.741508
15	2026-01-02	07:42:17	\N	4	1.00	110.00	1.00	1.00	1.00	0.00	11.00	\N	2026-01-04 07:42:17.179854	2026-01-04 07:42:17.179854
20	2026-01-04	15:42:23	\N	6	1.00	614.50	33.00	18.50	11.80	6.70	44.50	\N	2026-01-04 15:42:23.547461	2026-01-04 15:42:23.547461
21	2026-01-13	11:49:23	\N	3	1.00	372.00	18.00	2.95	2.95	0.00	31.50	\N	2026-01-13 11:49:23.738957	2026-01-13 11:49:23.738957
22	2026-01-13	11:49:35	288	\N	1.00	170.00	13.00	4.00	3.00	1.00	12.00	\N	2026-01-13 11:49:35.744031	2026-01-13 11:49:35.744031
23	2026-01-22	18:56:21	\N	2	1.00	290.00	21.00	0.00	0.00	0.00	23.00	\N	2026-01-22 18:56:21.276378	2026-01-22 18:56:21.276378
24	2026-01-22	18:56:31	\N	1	1.00	179.00	13.10	32.00	26.40	5.60	3.30	\N	2026-01-22 18:56:31.39336	2026-01-22 18:56:31.39336
\.


--
-- Data for Name: foods; Type: TABLE DATA; Schema: public; Owner: nomnom
--

COPY public.foods (id, name, calories, protein_grams, carbs_grams, fiber_grams, fat_grams, serving_size, serving_unit, is_custom, created_at, updated_at) FROM stdin;
1	Chicken Breast (cooked)	165.00	31.00	0.00	0.00	3.60	100	g	f	2026-01-02 11:16:41.399786	2026-01-02 11:16:41.399786
2	Salmon (cooked)	206.00	22.00	0.00	0.00	13.00	100	g	f	2026-01-02 11:16:41.413027	2026-01-02 11:16:41.413027
3	Ground Beef 85/15 (cooked)	215.00	26.00	0.00	0.00	12.00	100	g	f	2026-01-02 11:16:41.414906	2026-01-02 11:16:41.414906
4	Eggs (large)	72.00	6.00	0.40	0.00	5.00	1	egg	f	2026-01-02 11:16:41.416521	2026-01-02 11:16:41.416521
5	Greek Yogurt (plain, nonfat)	59.00	10.00	3.60	0.00	0.40	100	g	f	2026-01-02 11:16:41.417895	2026-01-02 11:16:41.417895
6	Tofu (firm)	144.00	17.00	3.00	2.00	9.00	100	g	f	2026-01-02 11:16:41.419262	2026-01-02 11:16:41.419262
7	Brown Rice (cooked)	112.00	2.60	24.00	1.80	0.90	100	g	f	2026-01-02 11:16:41.421153	2026-01-02 11:16:41.421153
8	White Rice (cooked)	130.00	2.70	28.00	0.40	0.30	100	g	f	2026-01-02 11:16:41.423063	2026-01-02 11:16:41.423063
9	Sweet Potato (baked)	90.00	2.00	21.00	3.30	0.20	100	g	f	2026-01-02 11:16:41.42503	2026-01-02 11:16:41.42503
10	Oatmeal (cooked)	71.00	2.50	12.00	1.70	1.50	100	g	f	2026-01-02 11:16:41.42733	2026-01-02 11:16:41.42733
11	Quinoa (cooked)	120.00	4.40	21.00	2.80	1.90	100	g	f	2026-01-02 11:16:41.429759	2026-01-02 11:16:41.429759
12	Whole Wheat Bread	247.00	13.00	41.00	7.00	3.40	100	g	f	2026-01-02 11:16:41.431835	2026-01-02 11:16:41.431835
13	Banana	89.00	1.10	23.00	2.60	0.30	1	medium	f	2026-01-02 11:16:41.436304	2026-01-02 11:16:41.436304
14	Apple	52.00	0.30	14.00	2.40	0.20	1	medium	f	2026-01-02 11:16:41.437812	2026-01-02 11:16:41.437812
15	Broccoli (cooked)	35.00	2.40	7.00	3.30	0.40	100	g	f	2026-01-02 11:16:41.439258	2026-01-02 11:16:41.439258
16	Spinach (raw)	23.00	2.90	3.60	2.20	0.40	100	g	f	2026-01-02 11:16:41.440486	2026-01-02 11:16:41.440486
17	Carrots (raw)	41.00	0.90	10.00	2.80	0.20	100	g	f	2026-01-02 11:16:41.44193	2026-01-02 11:16:41.44193
18	Bell Pepper (raw)	31.00	1.00	6.00	2.10	0.30	100	g	f	2026-01-02 11:16:41.44351	2026-01-02 11:16:41.44351
19	Kale (raw)	35.00	2.90	4.40	4.10	1.50	100	g	f	2026-01-02 11:16:41.445116	2026-01-02 11:16:41.445116
20	Avocado	160.00	2.00	8.50	6.70	15.00	100	g	f	2026-01-02 11:16:41.446737	2026-01-02 11:16:41.446737
21	Almonds	579.00	21.00	22.00	12.50	50.00	100	g	f	2026-01-02 11:16:41.448508	2026-01-02 11:16:41.448508
22	Olive Oil	884.00	0.00	0.00	0.00	100.00	100	ml	f	2026-01-02 11:16:41.450561	2026-01-02 11:16:41.450561
23	Peanut Butter	588.00	25.00	20.00	6.00	50.00	100	g	f	2026-01-02 11:16:41.45251	2026-01-02 11:16:41.45251
24	Cheddar Cheese	403.00	25.00	1.30	0.00	33.00	100	g	f	2026-01-02 11:16:41.454704	2026-01-02 11:16:41.454704
25	Whole Milk	61.00	3.20	4.80	0.00	3.30	100	ml	f	2026-01-02 11:16:41.4589	2026-01-02 11:16:41.4589
26	Skim Milk	34.00	3.40	5.00	0.00	0.10	100	ml	f	2026-01-02 11:16:41.459959	2026-01-02 11:16:41.459959
27	Whey Protein Powder	400.00	80.00	8.00	2.00	8.00	100	g	f	2026-01-02 11:16:41.461081	2026-01-02 11:16:41.461081
28	Five Cheese Tortellini (Costco)	270.00	13.00	37.00	3.00	8.00	1	\N	t	2026-01-02 12:10:48.819217	2026-01-02 12:10:48.819217
55	PB2 Peanut Butter Powder	60.00	8.00	6.00	2.00	2.00	16	\N	t	2025-12-06 15:27:39.034188	2025-12-06 15:27:39.034188
56	Sardines in Olive Oil	190.00	21.00	0.00	0.00	12.00	87	\N	t	2026-01-01 16:37:27.319331	2026-01-01 16:37:27.319331
57	Sardines in Water	140.00	18.00	0.00	0.00	8.00	85	\N	t	2026-01-01 16:38:07.62197	2026-01-01 16:38:07.62197
58	Olives (Costco Spanish Queen - stuffed with Pimento)	25.00	0.00	0.00	0.00	2.00	2	\N	t	2026-01-01 16:39:15.984876	2026-01-01 16:39:15.984876
59	Mayonnaise (Costco Avocado Oil Mayo)	100.00	0.00	0.00	0.00	11.00	14	\N	t	2026-01-01 16:41:31.379747	2026-01-01 16:41:31.379747
61	Pizza 1/2 (Costco Roasted Veggie / Cauliflower Crust)	460.00	24.00	54.00	4.00	16.00	252	\N	t	2026-01-02 13:20:52.018796	2026-01-02 13:20:52.018796
62	Greek Yogurt (Costco/Kirkland Fat Free)	100.00	18.00	7.00	0.00	0.00	170	\N	t	2026-01-02 13:25:03.424621	2026-01-02 13:25:03.424621
63	Sweet Pickle Relish	6.00	0.00	1.75	0.00	0.00	5	\N	t	2026-01-02 13:31:42.21855	2026-01-02 13:31:42.21855
64	Coconut Milk (Trader Joe's)	110.00	1.00	1.00	0.00	11.00	.25	\N	t	2026-01-03 08:40:10.236254	2026-01-03 08:40:10.236254
173	Salisbury Steak	319.00	23.00	14.00	1.00	19.00	4	\N	t	2026-01-04 09:23:41.885259	2026-01-04 09:23:41.885259
174	Mashed Potatoes	490.00	7.50	64.00	7.50	38.00	1	\N	t	2026-01-04 09:42:59.456934	2026-01-04 09:42:59.456934
202	Sour Cream	60.00	1.00	1.00	0.00	5.00	30	\N	t	2026-01-04 15:34:08.092206	2026-01-04 15:34:08.092206
203	Ground Beef 88/12 Cooked	210.00	22.00	0.00	0.00	13.00	113	\N	t	2026-01-04 15:35:15.823948	2026-01-04 15:35:15.823948
204	Tomato	22.00	1.00	3.50	0.00	0.00	123	\N	t	2026-01-04 15:37:20.213954	2026-01-04 15:37:20.213954
205	Cheddar Cheese (shredded	115.00	6.00	1.00	0.00	9.00	28	\N	t	2026-01-04 15:38:30.148474	2026-01-04 15:38:30.148474
206	Onion (white/yellow)	35.00	1.00	8.00	0.00	0.00	100	\N	t	2026-01-04 15:41:42.645163	2026-01-04 15:41:42.645163
288	Chicken and Apple Sausage Link (Costco)	170.00	13.00	4.00	1.00	12.00	90	\N	t	2026-01-13 11:49:03.958971	2026-01-13 11:49:03.958971
316	Ahi Tuna Steak (Sams)	130.00	29.00	0.00	0.00	1.00	4	\N	t	2026-01-22 19:04:12.476177	2026-01-22 19:04:12.476177
317	Shrimp - Argentine Wild Caught	80.00	19.00	0.00	0.00	0.50	4	\N	t	2026-01-22 19:06:02.497743	2026-01-22 19:06:02.497743
318	zucchini	21.00	1.50	3.90	1.20	0.40	124	\N	t	2026-01-22 19:12:32.287907	2026-01-22 19:12:32.287907
319	butter	102.00	0.00	0.00	0.00	12.00	12	\N	t	2026-01-22 19:13:36.959117	2026-01-22 19:13:36.959117
320	cabbage (1 cup)	22.00	1.00	3.00	0.00	0.00	89	\N	t	2026-01-22 19:48:35.962326	2026-01-22 19:48:35.962326
\.


--
-- Data for Name: meal_foods; Type: TABLE DATA; Schema: public; Owner: nomnom
--

COPY public.meal_foods (id, meal_id, food_id, servings, created_at) FROM stdin;
1	1	55	1.50	2025-12-06 15:29:23.947552
2	1	13	1.00	2025-12-06 15:29:23.947552
3	2	59	1.00	2026-01-01 16:46:32.991696
4	2	56	1.00	2026-01-01 16:46:32.991696
7	3	4	3.00	2026-01-02 13:33:09.472764
8	3	59	1.50	2026-01-02 13:33:09.472764
9	3	63	1.00	2026-01-02 13:33:09.472764
10	4	64	1.00	2026-01-03 08:40:51.472125
11	5	173	1.00	2026-01-04 09:54:50.976328
12	5	174	1.00	2026-01-04 09:54:50.976328
18	6	205	1.00	2026-01-04 15:41:58.434568
19	6	20	1.00	2026-01-04 15:41:58.434568
20	6	203	1.00	2026-01-04 15:41:58.434568
21	6	204	1.00	2026-01-04 15:41:58.434568
22	6	202	1.50	2026-01-04 15:41:58.434568
23	6	206	0.50	2026-01-04 15:41:58.434568
24	7	203	1.00	2026-01-04 15:54:44.364105
25	7	204	1.00	2026-01-04 15:54:44.364105
26	7	206	1.00	2026-01-04 15:54:44.364105
27	8	317	2.00	2026-01-22 19:15:54.998006
28	8	318	3.00	2026-01-22 19:15:54.998006
29	8	319	1.00	2026-01-22 19:15:54.998006
\.


--
-- Data for Name: meals; Type: TABLE DATA; Schema: public; Owner: nomnom
--

COPY public.meals (id, name, description, is_custom, created_at, updated_at) FROM stdin;
1	Banana and PB2	1 medium banana and 1.5 servings of PB2 powder	t	2025-12-06 15:29:23.947552	2025-12-06 15:29:23.947552
2	Sardine Salad	Basically tuna salad made with 1 can sardines	t	2026-01-01 16:46:32.991696	2026-01-01 16:46:32.991696
3	Egg Salad	\N	t	2026-01-02 13:30:20.551041	2026-01-02 13:33:09.472764
4	Matcha with Coconut Milk	Matcha with 3/8 cup coconut milk.	t	2026-01-03 08:40:51.472125	2026-01-03 08:40:51.472125
5	Salisbury Steak with Mashed Potatoes	1 patty and 1 cup mashed potatoes	t	2026-01-04 09:54:50.976328	2026-01-04 09:54:50.976328
6	Taco Bowl	\N	t	2026-01-04 15:40:35.19572	2026-01-04 15:41:58.434568
7	Taco Bowl (40/40/20)	\N	t	2026-01-04 15:54:44.364105	2026-01-04 15:54:44.364105
8	Shrimp and Zucchini	\N	t	2026-01-22 19:15:54.998006	2026-01-22 19:15:54.998006
\.


--
-- Name: food_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nomnom
--

SELECT pg_catalog.setval('public.food_log_id_seq', 24, true);


--
-- Name: foods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nomnom
--

SELECT pg_catalog.setval('public.foods_id_seq', 347, true);


--
-- Name: meal_foods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nomnom
--

SELECT pg_catalog.setval('public.meal_foods_id_seq', 29, true);


--
-- Name: meals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nomnom
--

SELECT pg_catalog.setval('public.meals_id_seq', 8, true);


--
-- Name: food_log food_log_pkey; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.food_log
    ADD CONSTRAINT food_log_pkey PRIMARY KEY (id);


--
-- Name: foods foods_name_key; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT foods_name_key UNIQUE (name);


--
-- Name: foods foods_pkey; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.foods
    ADD CONSTRAINT foods_pkey PRIMARY KEY (id);


--
-- Name: meal_foods meal_foods_meal_id_food_id_key; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods
    ADD CONSTRAINT meal_foods_meal_id_food_id_key UNIQUE (meal_id, food_id);


--
-- Name: meal_foods meal_foods_pkey; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods
    ADD CONSTRAINT meal_foods_pkey PRIMARY KEY (id);


--
-- Name: meals meals_pkey; Type: CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meals
    ADD CONSTRAINT meals_pkey PRIMARY KEY (id);


--
-- Name: idx_food_log_date; Type: INDEX; Schema: public; Owner: nomnom
--

CREATE INDEX idx_food_log_date ON public.food_log USING btree (log_date);


--
-- Name: idx_foods_name; Type: INDEX; Schema: public; Owner: nomnom
--

CREATE INDEX idx_foods_name ON public.foods USING btree (name);


--
-- Name: idx_meals_name; Type: INDEX; Schema: public; Owner: nomnom
--

CREATE INDEX idx_meals_name ON public.meals USING btree (name);


--
-- Name: food_log food_log_food_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.food_log
    ADD CONSTRAINT food_log_food_id_fkey FOREIGN KEY (food_id) REFERENCES public.foods(id) ON DELETE SET NULL;


--
-- Name: food_log food_log_meal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.food_log
    ADD CONSTRAINT food_log_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id) ON DELETE SET NULL;


--
-- Name: meal_foods meal_foods_food_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods
    ADD CONSTRAINT meal_foods_food_id_fkey FOREIGN KEY (food_id) REFERENCES public.foods(id) ON DELETE CASCADE;


--
-- Name: meal_foods meal_foods_meal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nomnom
--

ALTER TABLE ONLY public.meal_foods
    ADD CONSTRAINT meal_foods_meal_id_fkey FOREIGN KEY (meal_id) REFERENCES public.meals(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict gUSqEBZNEidv7gzKKbJXxzq8kwrAhSottxxgnWi6hxzqzGFHjyigK65FYltn00X

